# Contributing

Thanks for your interest in KODOSKOP Developer Kit. Open an issue first for behavior changes, API contracts, third-party integration, or security-sensitive designs. Keep pull requests focused and English-language. Include tests for logic changes, explain supported versions, and document any assumed server API schema.

```bash
python3 scripts/test_bridge.py
python3 -m compileall -q scripts bridge
```

No secrets, proprietary binaries, production logs, copyrighted code samples without permission, or malicious payloads may be committed. Only use synthetic/authorized fixtures. PRs may be released under the repository MIT license; submit only work you have rights to license. Report security issues privately using SECURITY.md.
