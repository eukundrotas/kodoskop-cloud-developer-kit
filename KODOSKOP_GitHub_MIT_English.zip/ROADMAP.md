# Roadmap

- **0.1.x (this repo):** agent skills, stdio MCP bridge, English developer docs, offline protocol tests.
- **Sprint 0:** ADRs, tenancy and security threat model, pinned integration versions and machine-readable OpenAPI DTOs.
- **Sprint 1:** actual auth, organizations, upload quarantine, S3 storage, job state machine and audit in a separate application implementation.
- **Sprint 2:** isolated static worker, REA/Ghidra capability checks, evidence provenance.
- **Sprint 3:** model provider, consent, budgets and schema-validated evidence claims.
- **Sprint 4:** browser UI, graph and reporting.
- **Sprint 5:** E2E and security verification, self-hosted deployment.

No dates, compatibility guarantees, or completion claims are implied.
