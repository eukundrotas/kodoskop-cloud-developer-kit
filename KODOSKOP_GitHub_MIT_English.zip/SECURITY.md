# Security policy

## Supported scope

Version 0.1.x is an **experimental developer kit**, not a production hosted service. There is no published vulnerability response SLA.

## Reporting vulnerabilities

Please **do not publish exploitable security reports in public GitHub issues**. After GitHub publication, use the repository's **Security → Report a vulnerability** private advisory channel if enabled. Until a private reporting channel is configured, avoid disclosing sensitive exploit details publicly; repository maintainers should add a private security contact before enabling public release.

## Security boundaries

Treat model prompts and uploaded software as untrusted. The bridge requires an explicit `KODOSKOP_API_URL` and scoped bearer token for live calls; do not commit tokens. Prefer HTTPS, minimal IAM scope, tenancy checks and auditable approvals on the API. The bridge does not enforce tenant permissions or legal authorization and must not be exposed as an internet-facing unauthenticated service. No dynamic execution, license bypass or unauthorized inspection are in scope.
