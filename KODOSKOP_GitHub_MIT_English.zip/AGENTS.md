# KODOSKOP engineering guidance

Read `docs/SPECIFICATION.md` before architectural changes. The original product requirements are dated October 20, 2026; the English document is a **summary, not a verbatim translation**. If implementation hinges on an unspecified DTO, model availability, or third-party capability, document the assumption and request verification rather than fabricate it.

Use `skills/`, `.agents/skills/` (Codex), or `.claude/skills/` (Claude Code with MiniMax API). Uploaded user code is never executed in MVP. Preserve evidence provenance, tenant isolation, auditable operations, cost budgets, and isolated workers. Never claim the SaaS or analysis engines are implemented by this developer kit. Verify changes with tests. Codex and MiniMax are development tools, not the KODOSKOP production AI model provider.
