---
name: kodoskop-ai-gateway
description: Implement KODOSKOP AI Gateway with one server-managed model, tool allowlists, evidence-grounded claims and budgets.
---

Use for KODOSKOP AI Gateway work. Follow sections 2, 6, 9 and 16 of the source specification. Keep provider ID in trusted server configuration; verify whether `gpt-6-astra` and its required API capabilities actually exist for the account before enabling it. Do not silently replace with another model. No browser-side key. Build ModelProvider interface, schema validation, bounded tool steps, explicit user consent for sending snippets, estimates and actual usage ledger, cancel/retry and idempotency. `confirmed` verdict requires evidence_refs; `probable`, `hypothesis`, `unknown` are explicit. Treat all analyzed strings as untrusted. Test mocked provider before integration testing with permitted credentials.

Source of truth: `docs/SPECIFICATION.md` in project root; do not invent implementation status.
