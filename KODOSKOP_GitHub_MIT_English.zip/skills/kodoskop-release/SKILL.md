---
name: kodoskop-release
description: Deploy and verify self-hosted KODOSKOP Cloud via Docker Compose with backups, smoke tests and operator documentation.
---

Use when preparing KODOSKOP deployment. Read sections 14-17 of the authoritative specification. Do not place Ghidra/REA in web/API images. Check production secrets, TLS, migrations, healthchecks, encryption, backup/restore, monitoring, least-privilege containers and worker separation. Output rollback procedure and evidence-backed test report. Do not mark release ready unless E2E with test PE, evidence, permission and configured model path pass. Avoid hardcoded credentials.

Source of truth: `docs/SPECIFICATION.md` in project root; do not invent implementation status.
