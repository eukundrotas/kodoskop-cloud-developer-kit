---
name: kodoskop-architecture
description: Design and implement KODOSKOP Cloud architecture, tenancy, RBAC, threat model, ADRs and API against the project v2.0 specification.
---

Use this skill when designing or implementing KODOSKOP Cloud architecture. Read `docs/SPECIFICATION.md` from repository root first. Preserve its explicit MVP boundaries. Work in Sprint 0-1 sequence: architecture decision records, threat model, tenancy matrix, data model, API contracts, queue FSM. Stack: Next.js, NestJS, PostgreSQL, Redis/BullMQ, S3/MinIO, worker isolation, Docker Compose. Do not use Codex CLI as product runtime. Record assumptions separately from spec decisions. Before claiming completion, run targeted tests and report commands/results.

Source of truth: `docs/SPECIFICATION.md` in project root; do not invent implementation status.
