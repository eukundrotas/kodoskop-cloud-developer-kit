---
name: kodoskop-security-review
description: Audit KODOSKOP Cloud against tenant isolation, static-analysis sandbox, authorization, prompt injection and operational security requirements.
---

Use this skill to security-review KODOSKOP. Read source sections 4, 12, 15-16. Check RBAC on every API and signed URL, IDOR, SSE leakage, queue scoped identity, object keys, secure cookies, CSRF, TLS, MFA for admins, quotas, worker isolation and egress prohibition. Confirm zero execution of untrusted uploaded code, and ensure no raw customer assets / tokens in logs or exports. Generate findings with severity, reproduction, mitigation, test status and file references. Never claim compliance based solely on a checklist.

Source of truth: `docs/SPECIFICATION.md` in project root; do not invent implementation status.
