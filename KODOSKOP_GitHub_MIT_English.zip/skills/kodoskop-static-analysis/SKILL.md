---
name: kodoskop-static-analysis
description: Build authorized static binary research pipeline using pinned REA, Ghidra and passive analyzers, retaining provenance and evidence.
---

Use this skill for KODOSKOP static research. Review sections 7-8 and 12-16 of the source specification. Process upload -> quarantine -> screening -> ready -> queued -> isolated static analysis -> evidence -> synthesis -> export. Do not execute uploaded binaries, package scripts, macros, install hooks or active HTML/SVG previews. Discover REA provider capabilities at runtime and mark unsupported features clearly. Use pinned verified versions, reproducible PE/ELF/.NET/Electron fixtures. Workers: no network egress, no API secrets, non-root, strict resource limits, disposable filesystem. Every claim must reference captured evidence including hashes and tool versions. Tests must cover zip bombs, path traversal, symlinks, malformed PE, and prompt injection in target bytes.

Source of truth: `docs/SPECIFICATION.md` in project root; do not invent implementation status.
