---
name: kodoskop-investigation
description: Use the KODOSKOP MCP bridge to list existing authorized analyses and inspect evidence-grounded results.
---

Use for already-deployed KODOSKOP Cloud investigations. Require a configured reachable KODOSKOP API endpoint and bearer token with appropriate scopes. Discover tools `kodoskop_health`, `kodoskop_get_analysis`, `kodoskop_get_evidence`, `kodoskop_get_claims`, `kodoskop_ask` and `kodoskop_create_analysis`. Never claim an analysis exists if API returns an error. For `kodoskop_ask`, ensure organization consent and budget policy at service level; do not send raw binaries to model. Report evidence refs, verdict and limitations. Ask for job ID when missing and cannot be obtained through approved project tooling.

Source of truth: `docs/SPECIFICATION.md` in project root; do not invent implementation status.
