#!/usr/bin/env python3
"""Minimal stdio MCP bridge to an existing KODOSKOP Cloud API (not the API itself)."""
import json
import os
import sys
import urllib.request
import urllib.error
import urllib.parse

BASE = os.getenv("KODOSKOP_API_URL", "").rstrip("/")
TOKEN = os.getenv("KODOSKOP_API_TOKEN", "")
TOOLS = [
    ("kodoskop_health", "Check remote KODOSKOP availability and auth configuration", {}, []),
    ("kodoskop_get_analysis", "Get an authorized analysis job", {"job_id": "string"}, ["job_id"]),
    ("kodoskop_get_evidence", "List evidence for an authorized analysis", {"job_id": "string"}, ["job_id"]),
    ("kodoskop_get_claims", "List evidence-backed claims for an analysis", {"job_id": "string"}, ["job_id"]),
    ("kodoskop_ask", "Ask a question about an existing authorized analysis", {"job_id": "string", "question": "string"}, ["job_id", "question"]),
    ("kodoskop_create_analysis", "Start static analysis of an already uploaded artifact", {"project_id": "string", "artifact_id": "string", "profile_id": "string", "budget_cap": "number"}, ["project_id", "artifact_id", "profile_id", "budget_cap"]),
]

def schema(properties, required):
    return {"type": "object", "properties": {k:{"type":v} for k,v in properties.items()}, "required":required, "additionalProperties":False}

def request(method, endpoint, payload=None):
    if not BASE or not TOKEN: raise ValueError("Set KODOSKOP_API_URL and KODOSKOP_API_TOKEN for a deployed server")
    if not BASE.startswith('https://') and not (BASE.startswith('http://127.0.0.1') or BASE.startswith('http://localhost')):
        raise ValueError("KODOSKOP_API_URL must use HTTPS, except localhost development")
    if not endpoint.startswith('/api/v1/'):
        raise ValueError("Unexpected endpoint")
    body=json.dumps(payload).encode() if payload is not None else None
    req=urllib.request.Request(BASE+endpoint, data=body, method=method, headers={"Authorization":"Bearer "+TOKEN,"Accept":"application/json","Content-Type":"application/json"})
    try:
        with urllib.request.urlopen(req,timeout=30) as res:
            raw=res.read(1024*1024)
            return {"status":res.status,"data":json.loads(raw) if raw else {}}
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"KODOSKOP returned HTTP {e.code}") from e

def part(value): return urllib.parse.quote(str(value), safe="")
def invoke(name,args):
    if name=="kodoskop_health": return {"configured":bool(BASE and TOKEN),"url":BASE or None,"note":"No external request made; API health endpoint not specified in v2.0"}
    if name=="kodoskop_get_analysis": return request("GET",f"/api/v1/analyses/{part(args['job_id'])}")
    if name=="kodoskop_get_evidence": return request("GET",f"/api/v1/analyses/{part(args['job_id'])}/evidence")
    if name=="kodoskop_get_claims": return request("GET",f"/api/v1/analyses/{part(args['job_id'])}/claims")
    if name=="kodoskop_ask": return request("POST",f"/api/v1/analyses/{part(args['job_id'])}/ask",{"question":args['question']})
    if name=="kodoskop_create_analysis": return request("POST",f"/api/v1/projects/{part(args['project_id'])}/analyses",{k:args[k] for k in ('artifact_id','profile_id','budget_cap')})
    raise ValueError("Unknown tool")

def handle(msg):
    method=msg.get('method'); params=msg.get('params') or {}; mid=msg.get('id')
    if method=='notifications/initialized': return None
    if mid is None: return None
    def response(result=None,error=None):
        return {"jsonrpc":"2.0","id":mid,**({"result":result} if error is None else {"error":{"code":-32603,"message":error}})}
    if method=='initialize':return response({"protocolVersion":"2025-03-26","serverInfo":{"name":"kodoskop-cloud-bridge","version":"0.1.0"},"capabilities":{"tools":{}}})
    if method=='ping':return response({})
    if method=='tools/list':return response({"tools":[{"name":n,"description":d,"inputSchema":schema(p,req)} for n,d,p,req in TOOLS]})
    if method=='tools/call':
        try:
            name=params.get('name'); args=params.get('arguments') or {}
            info=next((x for x in TOOLS if x[0]==name),None)
            if not info: raise ValueError('Unknown tool')
            for field in info[3]:
                if field not in args:raise ValueError(f'Missing {field}')
            result=invoke(name,args)
            return response({"content":[{"type":"text","text":json.dumps(result,ensure_ascii=False)}]})
        except Exception as e:
            return response({"content":[{"type":"text","text":str(e)}],"isError":True})
    return response(error=f'Unsupported method: {method}')

def main():
    for line in sys.stdin:
        try:
            msg=json.loads(line)
            reply=handle(msg)
            if reply is not None:
                sys.stdout.write(json.dumps(reply,ensure_ascii=False)+'\n');sys.stdout.flush()
        except Exception as e:
            sys.stderr.write(f'Bridge protocol error: {type(e).__name__}\n');sys.stderr.flush()
if __name__=='__main__': main()
