## Summary

## Motivation / reference specification

## Tests performed

- [ ] `python3 scripts/test_bridge.py`
- [ ] `python3 -m compileall -q scripts bridge`
- [ ] New behaviors have coverage
- [ ] No credentials, private binary data, or unverified claims
