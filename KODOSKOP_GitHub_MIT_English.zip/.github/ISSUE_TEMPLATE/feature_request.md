---
name: Feature request
about: Propose a skill, bridge, or documentation improvement
title: "[Feature] "
labels: enhancement
---

**Problem / use case:**

**Proposed change:**

**Relevant spec section / acceptance criteria:**

**Compatibility and security considerations:**
