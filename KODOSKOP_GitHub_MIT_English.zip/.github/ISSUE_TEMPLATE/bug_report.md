---
name: Bug report
about: Report reproducible behavior in the developer kit
title: "[Bug] "
labels: bug
---

**Environment:** OS, Python version, agent CLI/version.

**Expected behavior:**

**Actual behavior:**

**Reproduction steps:**

**Logs (remove credentials and private customer data):**
