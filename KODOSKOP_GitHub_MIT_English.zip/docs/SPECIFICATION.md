# KODOSKOP Cloud — English requirements summary (v2.0)

**Reference date:** October 20, 2026. **Status:** planning architecture. **Provenance:** summarized and adapted from the original Russian-language `KODOSKOP_CLOUD_FINAL_TZ.md` supplied by the project owner. **This is not a line-by-line English translation.** Do not interpret this developer kit as implementation of the target product.

## Purpose and scope

KODOSKOP Cloud is a web-based, self-hostable service for *authorized* examination of legacy software without source code. It aims to produce engineering dossiers, a defensible architectural reconstruction, evidence-linked claims, and a specification/test plan for independent modernization. It does not promise original source recovery, algorithm fidelity, unauthorized cloning, license circumvention, or the execution of customer binaries in the MVP.

Users access the system through a browser; no desktop application or local installation is required. Its production components are self-hosted except for explicitly consented calls to a closed AI model API. Initial deployments target Docker Compose on Linux; Kubernetes and distributed workers are later possibilities.

## Roles and product workflows

Roles: `platform_admin`, `org_owner`, `project_admin`, `analyst`, `viewer`. Each operation must be scoped to a valid organization, project, and permission.

Users can create organizations/projects; upload EXE/DLL, ELF, .NET and Electron/ASAR packages within an explicit support matrix; compute SHA-256 and metadata; launch bounded static research jobs; inspect functions, strings, graph, pseudocode and evidence; ask Russian-language questions; export dossiers/reports/specifications; cancel jobs; and review usage. Claims use `confirmed`, `probable`, `hypothesis`, or `unknown`. A claim without supporting evidence cannot be confirmed.

## Proposed components

| Layer | Planned technology |
| --- | --- |
| Web | Next.js, React, TypeScript, Tailwind, shadcn/ui |
| API | NestJS, TypeScript, REST/OpenAPI, SSE progress |
| Data | PostgreSQL, Prisma **or** Drizzle (choose one) |
| Async queue | Redis and BullMQ, at-least-once + idempotency |
| Artifacts | S3-compatible storage, e.g. MinIO |
| Research | Isolated ephemeral workers, version-pinned REA and Ghidra headless, passive parsers |
| AI | Server-owned `ModelProvider` interface and single configured provider |
| Infrastructure | Linux, Docker Compose, reverse proxy/TLS, backup/observability |
| Graph | React Flow or Cytoscape.js |

**Trust boundaries:** The browser never supplies host file paths. Research workers do not receive model API secrets, direct database privileges, unrelated tenant data, administrative API access or general internet egress. Service-to-service authorization is required. An AI Gateway is the only route to external inference.

## AI Gateway design

The upstream plan nominates `gpt-6-astra` via the official OpenAI Responses API as the single v1 model. **This ID and API availability require independent verification** before implementation and are not promised by this repository. No runtime dependency on Codex CLI. A narrow `ModelProvider.generate(messages, permittedTools, context, budget, cancellation)` contract isolates the model implementation. Add other providers only through a separate product decision.

Implement: fixed server-side model config, structured schemas, tool allowlists, bounded steps/tokens/time/budgets, rate-limit handling, idempotency, usage accounting, user consent before cloud disclosure, minimal evidence snippets, no frontend keys, and prompt-injection protection for extracted file content. Check the actual provider data-retention capabilities rather than assuming `store: false` alone is sufficient.

## Research job lifecycle

`created → uploaded → screening → ready → queued → running → synthesizing → completed|partial|failed|cancelled`, then an export can be produced. Maintain durable step checkpoints, leases, audit events and idempotency keys. Do not report `completed` without a baseline evidence manifest.

Uploads enter quarantine; server verifies digests and format, size and archive nesting. Never execute customer content: no lifecycle hooks, macros, scripts, active HTML previews or native binaries. Analysis workers must be non-root, tightly resource-limited, disposable, restricted by seccomp/AppArmor where applicable, with read-only inputs and private temp/cache. REA/Ghidra capabilities must be discovered and validated against pinned versions. Unsupported or packed formats receive explicit `unsupported`/`degraded` results.

## Evidence, tenancy and persistence

Planned entities include organizations, users, memberships, projects, artifacts, analysis_profiles, analysis_jobs, job_steps, analysis_functions, evidence, claims, agent_sessions, agent_turns, usage_ledger, exports, and audit_events. Generate storage object keys server-side. Tenant-filter every API query, file access, signed URL, event stream and queue operation; consider DB row-level security as additional protection. Preserve SHA-256, offsets, extraction methods, tool versions and limitations with claims and exports.

## Indicative API surface (DTOs are **not** fully specified)

- Authentication: `/api/v1/auth/login`, `/logout`, `/me`.
- Organizations and projects: `/api/v1/organizations`, `/api/v1/projects`.
- Uploads/artifacts: `/api/v1/projects/{projectId}/artifacts/uploads/init`, `/complete`, and artifacts list.
- Research: `POST /api/v1/projects/{projectId}/analyses`; `GET /api/v1/analyses/{jobId}` and `/events`, `/functions`, `/evidence`, `/claims`; `POST /cancel`, `/ask`, `/exports`.
- Metering: `/api/v1/organizations/{orgId}/usage`.

All endpoints require authorization and tenancy checks; downloads use short-lived signed URLs. Payload schemas must be agreed before claiming MCP write-path compatibility.

## Security and operation

Require TLS/HSTS, secure session cookies, CSRF/CORS controls, rate limits, MFA for platform admins, quarantine with fail-closed screening, zip-bomb/path traversal defenses, quotas, encrypted stored data/backups, tested restoration, audit logs that exclude private binary contents or secrets, and documented retention/deletion. Static-only MVP must never run unknown binaries. Future dynamic analysis requires separately isolated short-lived VMs and a new threat model.

The initial approximate single-host sizing is 8–16 vCPU, 32–64 GiB RAM and at least 200 GiB NVMe, subject to load tests. Production needs domain/TLS, SMTP, migrations/rollback, worker isolation and checks for backup/restore. Billing providers can follow later, but usage ledger and quotas are mandatory from the beginning. Proposed plans: TRIAL, PROFESSIONAL, TEAM, ENTERPRISE.

## Acceptance tests and phases

Acceptance includes test PE/ELF fixtures; correct SHA-256 and quarantine; static-only REA/Ghidra output; evidence-linked claims; cross-tenant IDOR and SSE isolation tests; worker cancellation and resource cleanup; stable retries without double billing; budget enforcement; adversarial archives/symlinks/prompt-injection checks; zero secret exposure; reproducible Markdown/JSON/PDF reports; and current operational documentation.

Delivery sequence: Sprint 0 architecture/threat model/ADRs/CI; Sprint 1 auth/tenancy/upload/job FSM; Sprint 2 static research; Sprint 3 AI gateway; Sprint 4 interface/reports; Sprint 5 hardening/self-hosted release. **No milestone is considered finished without executable end-to-end tests.**

## Upstream references

- [REA](https://github.com/morluto/rea)
- [REA installation](https://github.com/morluto/rea/blob/main/docs/installation.md)
- [REA Ghidra provider](https://github.com/morluto/rea/blob/main/docs/ghidra-provider.md)
- [OpenAI model documentation](https://developers.openai.com/api/docs/models)
- [OpenAI API pricing](https://developers.openai.com/api/docs/pricing)
