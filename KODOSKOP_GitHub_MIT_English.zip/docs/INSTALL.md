# Installation — Codex and MiniMax-backed Claude Code

This kit installs six Agent Skills and one lightweight MCP bridge **in a target project**. It does not deploy the KODOSKOP server or install REA/Ghidra.

## Requirements

- Python 3.10 or newer.
- OpenAI Codex CLI, and/or Claude Code CLI configured to call MiniMax models according to official MiniMax/Claude Code documentation.
- Write access to the destination project directory.

**Compatibility boundary:** “MiniMax Code” is not assumed to be a specific verified standalone CLI. This project documents and tests the **Claude Code CLI + MiniMax API** approach. A different MiniMax coding client must support skills and stdio MCP before you can use this configuration.

## Install skills and bridge

```bash
python3 scripts/install.py --target both --project /absolute/path/to/target-project
```

Windows PowerShell:

```powershell
py scripts/install.py --target both --project C:\projects\kodoskop
```

`--target codex` and `--target minimax` are available. The installer creates `.agents/skills/<skill>/SKILL.md` for Codex and `.claude/skills/<skill>/SKILL.md` for Claude Code, copies `.kodoskop/server.py` and `docs/SPECIFICATION.md`. Existing destinations are preserved by default. `--force` overwrites these assets: back up modifications first. Restart your agent session if needed.

## MCP configuration

From inside the target project, using an **absolute** bridge file path:

```bash
codex mcp add kodoskop-cloud -- python3 /absolute/path/to/target-project/.kodoskop/server.py
codex mcp list
```

```bash
claude mcp add --scope project kodoskop-cloud -- python3 /absolute/path/to/target-project/.kodoskop/server.py
claude mcp list
```

Set variables in the process running the client (shell or secure secret store):

```bash
export KODOSKOP_API_URL='https://your-kodoskop.example'
export KODOSKOP_API_TOKEN='YOUR_ACCESS_TOKEN' # do not save this line with a real token
```

If the server does not exist, you can still exercise `kodoskop_health` locally; it reports **configuration only**. The remaining tools require an authorized deployed KODOSKOP API with compatible DTOs. The bridge does not initiate uploads.

## Verify

```bash
python3 scripts/test_bridge.py
python3 -m compileall -q scripts bridge
```

The `.mcp.json` provided here is a **template**, not a guarantee that every client will expand environment placeholders in paths. CLI registration with a literal absolute path is recommended. No global agent settings or accounts are modified by the installer.

## Production caveats

Treat `kodoskop_create_analysis` and `kodoskop_ask` request bodies as provisional. Validate against an implemented OpenAPI contract before production usage. The required model ID in the upstream specification must be confirmed against model availability in the relevant provider account. Never expose provider keys to the browser or analysis workers. Only static analysis is authorized for the MVP.
