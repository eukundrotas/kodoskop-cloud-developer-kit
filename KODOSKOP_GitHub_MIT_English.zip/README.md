# KODOSKOP Cloud Developer Kit

[![CI](https://img.shields.io/badge/CI-GitHub%20Actions-blue)](.github/workflows/ci.yml) [![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE) ![Status: Developer kit](https://img.shields.io/badge/status-developer%20kit-orange)

**Reusable AI-agent skills and a lightweight Model Context Protocol (MCP) bridge for developing and interacting with a future self-hosted KODOSKOP Cloud deployment.** Designed for OpenAI Codex and Claude Code configured with MiniMax models.

> **Scope notice:** This repository is **not** a running KODOSKOP Cloud SaaS, a binary decompiler, or a hosted analysis service. It does not install REA, Ghidra, databases, or the web application. Its MCP bridge only calls an **existing** authorized KODOSKOP API. Write endpoints use provisional request DTOs pending an agreed OpenAPI specification.

## What is included

- Six skills: `kodoskop-architecture`, `kodoskop-static-analysis`, `kodoskop-ai-gateway`, `kodoskop-security-review`, `kodoskop-release`, `kodoskop-investigation`.
- A Python standard-library JSON-RPC/stdio MCP adapter exposing six tools.
- A project-local installer for Codex skill directories and Claude Code skill directories.
- English architecture summary, install instructions, contribution/security policies, and automated offline tests.

## Quick start

Requires Python 3.10+ and an installed coding-agent CLI. No dependencies are needed for the bridge.

```bash
# From the cloned repository; use an absolute path to your target project
python3 scripts/install.py --target both --project /absolute/path/to/project
python3 scripts/test_bridge.py
```

For Codex, register the MCP bridge using the absolute installed path:

```bash
codex mcp add kodoskop-cloud -- python3 /absolute/path/to/project/.kodoskop/server.py
codex mcp list
```

For Claude Code **using the separately configured MiniMax API**:

```bash
claude mcp add --scope project kodoskop-cloud -- python3 /absolute/path/to/project/.kodoskop/server.py
claude mcp list
```

Before remote operations, set `KODOSKOP_API_URL` and `KODOSKOP_API_TOKEN` in the environment of the agent process. Use HTTPS outside localhost. **Never commit credentials.** Refer to [installation](docs/INSTALL.md) for Windows, limitations, and troubleshooting.

## MCP tools

| Tool | Behavior |
| --- | --- |
| `kodoskop_health` | Reports local bridge configuration, **not** remote API health |
| `kodoskop_get_analysis` | GET analysis status |
| `kodoskop_get_evidence` | GET referenced evidence |
| `kodoskop_get_claims` | GET evidence-backed claims |
| `kodoskop_ask` | POST a question about an analysis; request body provisional |
| `kodoskop_create_analysis` | POST an analysis job; request body provisional |

All server-side authorization, legal consent, tenant checks, billing controls and auditing remain responsibilities of KODOSKOP Cloud. The bridge does not implement or bypass them.

## Security and research boundaries

The target MVP performs **static-only, authorized software analysis**. Uploaded programs must not be executed; no license bypass or unauthorized access is supported. Treat binaries and extracted text as untrusted. See [SECURITY.md](SECURITY.md) and [specification summary](docs/SPECIFICATION.md).

## Project state and roadmap

**0.1.0 — developer integration tooling.** Local MCP protocol and installer tests are available. No live hosted API, paid-model integration, deployment, end-to-end binary analysis, or third-party analyzer conformance is asserted. Refer to [ROADMAP.md](ROADMAP.md) for phased development.

## Documentation

[Installation](docs/INSTALL.md) · [Product architecture and requirements summary](docs/SPECIFICATION.md) · [Contributing](CONTRIBUTING.md) · [Security](SECURITY.md) · [Code of Conduct](CODE_OF_CONDUCT.md)

## License

MIT © 2026 KODOSKOP Contributors. Third-party components, including REA and Ghidra, are **not redistributed in this repository** and retain their own licenses. See [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md). The KODOSKOP name is not granted as a trademark license by MIT.
