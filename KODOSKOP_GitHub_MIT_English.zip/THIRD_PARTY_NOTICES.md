# Third-party notices

This repository does not vendor, bundle, or redistribute REA, Ghidra, or any commercial AI model. Planned integration targets include:

- REA (`morluto/rea`): https://github.com/morluto/rea — verify the current upstream license and compatible release before redistribution/integration.
- Ghidra: https://github.com/NationalSecurityAgency/ghidra — verify version, dependencies, and upstream license before distribution.
- OpenAI API / MiniMax APIs: governed by their separate service terms and availability.

MIT licensing of **this repository** does not override the licensing or trademarks of independent dependencies or services. No upstream code is included in this archive.
