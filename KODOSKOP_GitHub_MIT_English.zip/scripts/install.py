#!/usr/bin/env python3
"""Safe project-local skill/bridge installer. Does not overwrite files without --force."""
import argparse, pathlib, shutil, sys, json
p=argparse.ArgumentParser()
p.add_argument('--target',choices=['codex','minimax','both'],default='both')
p.add_argument('--project',default='.')
p.add_argument('--force',action='store_true')
a=p.parse_args()
root=pathlib.Path(__file__).resolve().parents[1]; project=pathlib.Path(a.project).resolve()
project.mkdir(parents=True,exist_ok=True)
paths=[]
if a.target in ('codex','both'):paths.append(project/'.agents'/'skills')
if a.target in ('minimax','both'):paths.append(project/'.claude'/'skills')
for dest in paths:
    for source in sorted((root/'skills').iterdir()):
        out=dest/source.name
        if out.exists() and not a.force:
            print('SKIP existing:',out);continue
        if out.exists():shutil.rmtree(out)
        dest.mkdir(parents=True,exist_ok=True)
        shutil.copytree(source,out);print('INSTALLED skill:',out)
# Install bridge in a stable project location; do not edit client global config.
bridge=project/'.kodoskop'/'server.py'
bridge.parent.mkdir(parents=True,exist_ok=True)
if not bridge.exists() or a.force:
    shutil.copy2(root/'bridge'/'server.py',bridge)
    print('INSTALLED bridge:',bridge)
else:print('SKIP existing bridge:',bridge)
spec=project/'docs'/'SPECIFICATION.md'
spec.parent.mkdir(parents=True,exist_ok=True)
if not spec.exists() or a.force:
    shutil.copy2(root/'docs'/'SPECIFICATION.md',spec)
    print('INSTALLED spec summary:',spec)
print('\nNext: see docs/INSTALL.md. No system/global agent config modified, no remote deployment.')
