import importlib.util,json,pathlib
p=pathlib.Path(__file__).resolve().parents[1]/'bridge/server.py'
s=importlib.util.spec_from_file_location('bridge',p); m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
assert len(m.handle({'jsonrpc':'2.0','id':1,'method':'tools/list'})['result']['tools'])==6
assert m.handle({'jsonrpc':'2.0','id':2,'method':'initialize','params':{}})['result']['serverInfo']['name']=='kodoskop-cloud-bridge'
assert m.handle({'jsonrpc':'2.0','id':3,'method':'tools/call','params':{'name':'kodoskop_get_analysis','arguments':{}}})['result']['isError']
assert m.handle({'jsonrpc':'2.0','id':4,'method':'tools/call','params':{'name':'kodoskop_health','arguments':{}}})['result']['content']
print('OK: initialize, discovery, validation, offline health')
