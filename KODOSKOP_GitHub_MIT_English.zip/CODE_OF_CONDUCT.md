# Code of Conduct

Contributors and maintainers are expected to communicate respectfully, assume good faith, avoid harassment or discrimination, and resolve technical disagreements with evidence. Maintainers may edit, hide, or remove abusive contributions and restrict participation. For sensitive conduct matters, use a private contact provided by maintainers when available; do not disclose personal information publicly.
